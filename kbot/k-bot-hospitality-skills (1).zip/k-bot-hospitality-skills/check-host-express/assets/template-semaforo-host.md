# Template pagella HTML — check-host-express

HTML single-page self-contained. File `check-host-{slug_struttura}-{YYYYMMDD}.html` in `/mnt/outputs/`. Zero dipendenze esterne, apribile offline.

## Scopo

Il titolare apre il file, scrolla 3 minuti, capisce come e messo. Stampabile, shareabile via link al commercialista o al socio.

## Struttura verticale

### 1. Header (altezza 96px)
- Logo K2-AI a sinistra (SVG inline)
- Titolo "Check Ricettivo — {nome struttura}" centrato
- Data generazione a destra
- Sfondo gradient `#1F3864` → `#2E75B6`, testo bianco

### 2. Hero score globale (altezza 280px)
- Cerchio gauge grande (diametro 180px) con score 0-100 al centro
- Arco colorato: rosso 0-44, giallo 45-64, verde 65-100
- Etichetta giudizio sotto: "Eccellente" / "Buono" / "Sufficiente" / "Preoccupante" / "Critico"
- A destra, dati struttura: tipologia, regione, camere, giorni apertura
- A sinistra, un claim tipo "Stai facendo meglio del 65% degli agriturismi della tua zona" calcolato dal percentile

### 3. Semaforo 6 KPI (grid 3x2)
Ogni card:
- Icona grande colorata (verde circle / yellow triangle / red square)
- Nome KPI
- Valore tua struttura (grande, bold)
- Benchmark zona (piu piccolo, sotto)
- Commento di 1 riga: "in linea con la tua zona" / "sotto la mediana" / "molto basso"
- Barra orizzontale mini con segnalino "tu" vs "mediana zona"

### 4. Top 3 priorita (accordion)
3 card espandibili prioritizzate. Ogni card:
- Badge priorita (1, 2, 3)
- Titolo con verbo imperativo ("Ribilancia i canali di vendita")
- Riga sintesi: "stai facendo X EUR, la zona fa Y EUR. Si puo migliorare."
- Click per espandere: 3-4 righe di spiegazione pratica + cosa fare entro 30 giorni

### 5. CTA verso HostBoost
- Banner pieno largo, sfondo `#F39C12` chiaro
- "Vuoi capire come crescere concretamente?"
- "HostBoost analizza i tuoi dati di 12 mesi, costruisce il cruscotto KPI, ti da un calendario di pricing e 5 azioni prioritarie con ROI atteso."
- Bottone "Prenota call con K2-AI" (link mailto o al sito)
- Prezzo indicativo "da 899 EUR una tantum"

### 6. Footer
- "Questo e un check rapido, non una diagnosi. Per un piano operativo serve HostBoost."
- Data generazione
- "Powered by K2-AI — k2-ai.it"

## Tecnologia

### Nessun framework
HTML + CSS + JS vanilla. Tutto in un singolo file, 1-2 immagini SVG inline (logo + gauge arc). Niente CDN — offline friendly.

### Gauge score centrale
SVG inline con arco tracciato via `<path>` e animazione `stroke-dasharray`. Esempio:

```html
<svg viewBox="0 0 200 200" width="180" height="180">
  <circle cx="100" cy="100" r="80" stroke="#E0E0E0" stroke-width="20" fill="none"/>
  <circle cx="100" cy="100" r="80" stroke="url(#scoreGradient)" stroke-width="20" fill="none"
          stroke-dasharray="{circumference × score/100} {circumference}"
          stroke-linecap="round" transform="rotate(-90 100 100)"/>
  <text x="100" y="100" text-anchor="middle" dy="0.3em" font-size="48" font-weight="700" fill="#1F3864">{score}</text>
  <text x="100" y="130" text-anchor="middle" font-size="14" fill="#7F8C8D">/ 100</text>
</svg>
```

Gradient da rosso (0%) a verde (100%) in `<defs>` + `<linearGradient>`.

### Colori
Variabili CSS in alto:
```css
:root {
  --primary: #1F3864;
  --secondary: #2E75B6;
  --accent: #F39C12;
  --green: #548B54;
  --green-bg: #C6EFCE;
  --yellow: #E6B800;
  --yellow-bg: #FFEB9C;
  --red: #C0392B;
  --red-bg: #FFC7CE;
  --bg: #F8F9FA;
  --card: #FFFFFF;
  --text: #2C3E50;
  --text-muted: #7F8C8D;
}
```

### Responsive
Grid mobile-first:
- < 600px: semafori in colonna singola, gauge centrato
- 600-900px: semafori 2 colonne
- > 900px: semafori 3 colonne, layout ottimale

### Stampa
`@media print`:
- Accordion tutti espansi
- Background solido bianco per risparmio toner
- Spezzature pagina pulite dopo hero e dopo semafori
- Footer con URL e data

### Accessibility
- ARIA labels sui gauge e sulle card
- Testo alternativo per i colori semaforo (icona + label, non solo colore)
- Contrasto AA minimo su tutti i testi

## Scheletro HTML (essenziale)

```html
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Check Ricettivo — {nome}</title>
<style>/* variabili CSS + layout */</style>
</head>
<body>

<header class="header">
  <div class="logo">K2-AI</div>
  <h1>Check Ricettivo — {nome}</h1>
  <div class="date">{data}</div>
</header>

<section class="hero">
  <div class="gauge-container">{SVG gauge score}</div>
  <div class="hero-text">
    <div class="judgment">{giudizio}</div>
    <p>{claim con percentile}</p>
    <div class="structure-info">
      <span>{tipologia}</span><span>{regione}</span>
      <span>{camere} camere</span><span>{giorni_apertura} gg/anno</span>
    </div>
  </div>
</section>

<section class="semafori">
  <h2>I tuoi 6 KPI rispetto alla zona</h2>
  <div class="grid-3x2">
    <div class="kpi-card {green|yellow|red}">
      <div class="status-icon">●</div>
      <h3>RevPAR vs zona</h3>
      <div class="value">{valore} EUR</div>
      <div class="benchmark">Mediana zona: {mediana} EUR</div>
      <div class="comment">{commento in italiano}</div>
      <div class="mini-bar"><!-- barra con marker --></div>
    </div>
    <!-- ... altre 5 card -->
  </div>
</section>

<section class="priorities">
  <h2>I 3 punti da affrontare per primi</h2>
  <div class="accordion">
    <details open>
      <summary>
        <span class="priority-badge">1</span>
        <span class="action-title">{verbo imperativo + nome}</span>
        <span class="sintesi">{numeri chiave}</span>
      </summary>
      <div class="details-content">
        <p>{spiegazione 2-3 righe}</p>
        <p><strong>Cosa fare entro 30 giorni:</strong> {azione concreta}</p>
      </div>
    </details>
    <!-- 2, 3 -->
  </div>
</section>

<section class="cta">
  <h2>Vuoi un piano operativo, non solo la pagella?</h2>
  <p>HostBoost analizza i tuoi dati di 12 mesi, costruisce un cruscotto KPI vivo, disegna il calendario di pricing e ti consegna 5 azioni prioritarie con ROI atteso.</p>
  <a href="mailto:info@k2-ai.it?subject=Interesse HostBoost" class="cta-button">Prenota una call</a>
  <div class="cta-price">da 899 EUR una tantum</div>
</section>

<footer>
  <p>Check rapido generato il {data}. Per un piano operativo serve HostBoost.</p>
  <p>Powered by <a href="https://k2-ai.it">K2-AI</a></p>
</footer>

</body>
</html>
```

## Accorgimenti comunicativi

- **Numeri con contesto zona**: mai dire solo "tu fai 42 EUR RevPAR", sempre "tu 42, zona 58".
- **Verbi al tu, non al lei**: tono consulente amico.
- **Mai giudizi morali**: "sotto la mediana" non "stai andando male".
- **Sempre percentile nella hero**: "meglio del X%" da contesto immediato.
- **CTA non aggressivo**: banner chiaro, un bottone, prezzo trasparente. Niente popup, niente countdown, niente "ultimi posti".
- **Disclaimer onesto in footer**: il check e un primo screening, non un piano.

## File size target

< 80 KB totale (HTML + CSS + SVG inline). Nessuna immagine pesante. Se serve screenshot condivisibile, fornire il DOCX rigenerato via la skill `flusso-hostboost-ricettive` successiva.
