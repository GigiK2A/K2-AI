# Template Dashboard HTML — HostBoost

Dashboard HTML self-contained consegnata al cliente per lettura rapida sul telefono o sul desktop. File unico, apribile offline. Zero dipendenze esterne eccetto CDN di Chart.js.

## Scopo

Un singolo file `hostboost-{slug}-{YYYYMMDD}-dashboard.html` che il titolare apre dal browser e scrolla in 5 minuti per avere il quadro della situazione. Se vuole approfondire va sul DOCX; se vuole modificare i dati va sull'XLSX.

## Struttura a singola pagina

### Header fisso (altezza 72px)
- Logo K2-AI a sinistra (SVG inline)
- Titolo "HostBoost — {Nome Struttura}" al centro
- Data consegna a destra
- Sfondo sfumato `#1F3864` → `#2E75B6`, testo bianco

### Hero section (altezza 180px)
- 3 card KPI affiancate: RevPAR attuale, RevPAR target 12 mesi, Delta vs zona
- Ogni card: valore grande (font-size 36px bold), label piccola, icona, barra di progresso o freccia trend
- Colore semaforo sul bordo sinistro: verde / giallo / rosso

### Sezione 1 — KPI core (grid 2x2)
Card 1 — ADR:
- Numero grande attuale
- Sotto: benchmark zona + semaforo
- Mini grafico linea 12 mesi

Card 2 — Occupancy:
- Numero % grande
- Benchmark + semaforo
- Mini grafico linea 12 mesi

Card 3 — RevPAR:
- Numero grande
- Benchmark + semaforo
- Mini grafico linea 12 mesi con area fill

Card 4 — ALOS + Booking window + Cancellation rate:
- Tre numeri piccoli affiancati

### Sezione 2 — Stagionalita (full width)
Grafico combo:
- Linea RevPAR mensile
- Barre Occupancy mensile
- Legenda sotto
- Etichette fasce: BASSA / SPALLA / MEDIA / ALTA sui mesi corrispondenti
- Responsive, altezza 360px

### Sezione 3 — Distribuzione canali (2 colonne)
Colonna sinistra: Pie chart mix attuale
- 4-5 slice (Diretto, Booking, Expedia, Airbnb, Altri)
- Tooltip con % notti e % ricavi

Colonna destra: Pie chart mix target 12 mesi
- Stesso format, colori diversi (desaturati) per distinguere
- Sotto: tabella con delta canale per canale

### Sezione 4 — Benchmark zona (full width)
Tabella comparativa responsive:
| Metrica | Tua struttura | Mediana zona | Top quartile | Semaforo |
|---|---|---|---|---|
| Occupancy | valore | valore | valore | pallino colorato |
| ADR | valore | valore | valore | pallino |
| RevPAR | valore | valore | valore | pallino |
| Quota diretto | valore | valore | valore | pallino |
| Rating Booking | valore | valore | valore | pallino |

### Sezione 5 — Pricing vs compset (full width)
Scatter chart:
- Asse X: date campione
- Asse Y: prezzo EUR
- Serie cliente (linea spessa) vs serie compset 1-5 (linee sottili)
- Linea tratteggiata mediana compset
- Tooltip con nome struttura e data

### Sezione 6 — Recensioni (grid 3 colonne)
Colonna 1 — Rating gauges:
- 4 semi-gauge (Booking, TripAdvisor, Google, Airbnb)
- Valore al centro, scala colorata

Colonna 2 — Top temi positivi:
- Barre orizzontali con frequenza

Colonna 3 — Top temi negativi:
- Barre orizzontali con frequenza, tonalita rossastra

### Sezione 7 — Piano ricavi 12 mesi (full width)
Grafico barre comparativo:
- 3 scenari (pessimistico / base / ottimistico)
- 4 metriche (RevPAR, Occupancy, ADR, Ricavi annuali)
- Tooltip dettagliati

### Sezione 8 — Azioni prioritarie (accordion)
5 card espandibili, ogni card:
- Header: priorita + nome azione + semaforo fattibilita + badge costo
- Body: impatto stimato, tempo, come si fa (2-3 righe), responsabile
- Click per espandere

### Footer
- "Generato il {data}. Per aggiornamenti apri il cruscotto XLSX."
- Contatti K2-AI
- Claim: "Il revenue manager che non hai, costruito su misura sulla tua struttura."

## Tecnologia

### Framework
Nessun framework. Vanilla HTML + CSS + JS. Tutto in un file `.html`.

### CSS
Variabili CSS per tema:
```css
:root {
  --primary: #1F3864;
  --secondary: #2E75B6;
  --green: #548B54;
  --yellow: #E6B800;
  --red: #C0392B;
  --bg: #F8F9FA;
  --card-bg: #FFFFFF;
  --text: #2C3E50;
  --text-muted: #7F8C8D;
}
```

Grid responsive mobile-first con breakpoint a 768px e 1200px.

### JavaScript
Solo Chart.js 4.x da CDN `https://cdn.jsdelivr.net/npm/chart.js@4.x.x/dist/chart.umd.min.js`.

Dati inline in JSON dentro `<script>` tag all'inizio del file.

Tutti i grafici costruiti con Chart.js:
- Line chart → ADR/Occ/RevPAR mensile, pricing vs compset
- Bar chart → scenari, temi recensioni
- Pie chart → mix canali
- Doughnut → gauge rating
- Combo bar+line → stagionalita

### Accessibilita
- Rapporti contrasto WCAG AA
- Etichette ARIA sui grafici
- Tabelle navigabili da tastiera
- Testo alternativo per tutti i numeri nei grafici

### Stampa
CSS `@media print` che:
- Nasconde accordion (stampa tutto espanso)
- Forza colori per stampa (no sfondi scuri)
- Mantiene grafici come immagini
- Spezza per pagine su sezioni

## Esempio scheletro HTML (prime 100 righe)

```html
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HostBoost — {Nome Struttura}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root { /* vars */ }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--bg); color: var(--text); }
.header { position: sticky; top: 0; height: 72px; background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; display: flex; align-items: center; justify-content: space-between; padding: 0 24px; z-index: 10; }
.hero { padding: 24px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.kpi-card { background: var(--card-bg); border-radius: 8px; padding: 16px; border-left: 4px solid var(--green); box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
.kpi-card.yellow { border-left-color: var(--yellow); }
.kpi-card.red { border-left-color: var(--red); }
.kpi-value { font-size: 36px; font-weight: 700; color: var(--primary); }
.kpi-label { font-size: 12px; text-transform: uppercase; color: var(--text-muted); letter-spacing: 0.5px; }
.section { padding: 32px 24px; max-width: 1200px; margin: 0 auto; }
.section h2 { font-size: 24px; color: var(--primary); margin-bottom: 16px; border-bottom: 2px solid var(--secondary); padding-bottom: 8px; }
/* ... altre classi */
@media (max-width: 768px) {
  .hero { grid-template-columns: 1fr; }
  .kpi-value { font-size: 28px; }
}
@media print {
  .accordion { display: block !important; }
  body { background: white; }
}
</style>
</head>
<body>
<script id="data" type="application/json">
{ /* JSON con tutti i dati */ }
</script>
<header class="header">
  <div class="logo">K2-AI</div>
  <div class="title">HostBoost — {Nome Struttura}</div>
  <div class="date">{data}</div>
</header>
<section class="hero"><!-- 3 card KPI --></section>
<!-- ... altre sezioni -->
<script>
const data = JSON.parse(document.getElementById('data').textContent);
// Render grafici Chart.js
// Render tabelle
// Bind accordion
</script>
</body>
</html>
```

## Accorgimenti

- **Peso file**: target < 500 KB inclusi i dati. Chart.js da CDN, non inline.
- **Offline**: per uso offline stampare PDF dal browser.
- **Responsive**: testato su iPhone 13 e Galaxy S22.
- **Anti-stale**: footer con data di generazione. Se il cliente torna dopo 3 mesi sa che i dati sono vecchi.
- **Theming**: variabili CSS in alto facili da cambiare per white label futuro.
- **Niente tracking**: nessuna analytics embedded, nessun link esterno (eccetto CDN Chart.js).
